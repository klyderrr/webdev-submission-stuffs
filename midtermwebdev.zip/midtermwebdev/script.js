document.addEventListener("DOMContentLoaded", () => {
    const screen = document.getElementById("screen");
    const buttons = document.querySelectorAll(".buttons button");
    const darkModeToggle = document.getElementById("dark-mode-toggle");
    let expression = "";

    buttons.forEach(button => {
        button.addEventListener("click", () => {
            const value = button.getAttribute("data-value");

            if (button.id === "clear") {
                expression = "";
            } else if (button.id === "backspace") {
                expression = expression.slice(0, -1);
            } else if (button.id === "equal") {
                try {
                    if (expression.includes("/0")) throw new Error("Cannot divide by zero");
                    expression = eval(expression.replace(/√(\d+(\.\d+)?)/g, "Math.sqrt($1)")).toString();
                } catch {
                    expression = "Error";
                }
            } else if (button.id === "sqrt") {
                if (expression === "" || /[+\-*/]$/.test(expression.slice(-1))) {
                    expression += "√"; 
                } else {
                    try {
                        expression = expression.replace(/(\d+(\.\d+)?)$/, "√$1");
                    } catch {
                        expression = "Error";
                    }
                }
            } else if (button.id === "percentage") {
                try {
                    if (expression === "" || /[+\-*/]$/.test(expression)) {
                        throw new Error("Invalid Input");
                    }
                    expression = (eval(expression) / 100).toString();
                } catch {
                    expression = "Error";
                }
            } else if (value) {
                if (
                    ["+", "-", "*", "/"].includes(value) &&
                    ["+", "-", "*", "/"].includes(expression.slice(-1))
                ) {
                    return; 
                }
                expression += value;
            }

            screen.value = expression;
        });
    });

    darkModeToggle.addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");
    });

    document.addEventListener("keydown", (e) => {
        if ((e.key >= "0" && e.key <= "9") || ["+", "-", "*", "/", "."].includes(e.key)) {
            expression += e.key;
        } else if (e.key === "Enter") {
            try {
                if (expression.includes("/0")) throw new Error("Cannot divide by zero");
                expression = eval(expression.replace(/√(\d+(\.\d+)?)/g, "Math.sqrt($1)")).toString();
            } catch {
                expression = "Error";
            }
        } else if (e.key === "Backspace") {
            expression = expression.slice(0, -1);
        } else if (e.key === "Escape") {
            expression = "";
        } else if (e.key === "r") { 
            expression += "√";
        }
        screen.value = expression;
    });
});
